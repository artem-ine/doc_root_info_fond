<body>
    <center>
        <?php
 
        // nom du serveur => localhost
        // username => root
        // mdp => empty
        // nom de la base de données => unpatronized_stairs
        // conn créé une nouvelle connection à mysql
        $conn = mysqli_connect("localhost", "id18751386_root", "4FZnfR)By[C#q&fJ", "id18751386_test_db");
         
        // on récupère les données que l'utilisateur nous a donné avec POST, valeur par défaut
        $pseudonyme =  $_POST['pseudonyme'];
        $email = $_POST['email'];
        $date =  $_POST['date'];
        $heure = $_POST['heure'];
        $sf_rec = $_POST['sf_rec'];
        $last_words = $_POST['last_words'];
        
        // demande à l'utilisateur de bien remplir tous les champs du formulaire
        if (empty($pseudonyme)){
    		die("N'oubliez pas votre pseudonyme !");
    	}
    	
    	// vérifie que l'email est valide en le filtrant pour des erreurs/oublis
    	if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)){
    		die("Il faut rentrer un email valide.");
    	}
    	
    	if (empty($sf_rec)){
    		die("Allez, balancez un titre !");
    	}
    	
    	if (empty($last_words)){
    		die("Ne restez pas silencieux.");
    	}	        
         
        // vérifie la connection
        if($conn === false){
            die("ERROR: Could not connect. "
                . mysqli_connect_error());
        }
         
        // on insert tout ça dans notre table créée auparavant
        $sql = "INSERT INTO formulaire VALUES ('$pseudonyme',
            '$email','$date','$heure','$sf_rec', '$last_words')";
        
        // si tout a fonctionné, on le dit, sinon, on prévient   
        if(mysqli_query($conn, $sql)){
            echo "<h3>merci ! nous avons bien enregistré vos réponses.</h3>";
 
            echo nl2br("\n$pseudonyme\n $email\n "
                . "$date\n $heure\n $sf_rec \n $last_words");
        } else{
            echo "ERROR: Oops. $sql. "
                . mysqli_error($conn);
        }
         
        // on ferme la connection
        mysqli_close($conn);
        ?>
    </center>
</body>
</html>